package persistence;

import helper.Product;
import helper.ProductXML;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Product_CRUD extends HttpServlet {
    
    private static Connection getConnection(){
        Connection con=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Farm2CartProducts?zeroDateTimeBehavior=CONVERT_TO_NULL","root","student");
        }catch(Exception e){System.out.println(e);}
        return con;
    }
    
    public static Set<Product> searchForProducts(String query){
        Set<Product> products= new HashSet<Product>();
        try{
            Connection con= getConnection();
            
            String q = "select * from Product WHERE Name LIKE '%"+query+"%'"
                    + " OR Category LIKE '%"+
                    query+"%' OR SellerUsername LIKE '%"+
                    query+"%' OR Description LIKE '%"+
                    query+"%';";
            System.out.println(q);
            PreparedStatement ps=con.prepareStatement(q);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                    Product product = new Product();
                    product.setProductName(rs.getString("Name"));
                    product.setProductSeller(rs.getString("SellerUsername"));
                    product.setProductDescription(rs.getString("Description"));
                    product.setProductPrice(rs.getDouble("Price"));
                    product.setProductStock(rs.getInt("Stock"));
                    product.setProductSize(rs.getDouble("ProductSize"));
                    product.setProductSizeUnit(rs.getString("ProductUnit"));
                    product.setProductCategory(rs.getString("Category"));
                    product.setAvailable(rs.getBoolean("Available"));
                    
                    products.add(product);

                    }

            con.close();

		}catch(Exception e){System.out.println(e);}
            
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>"+products.size());
        return products;
        
    }
    
    /* Find Products
    public static ProductXML searchForaProducts(String productName)
    {
        StringBuilder sql = new StringBuilder("SELECT * FROM Product WHERE Name Like ?");
        List<Object> parameters = new ArrayList<>();

        if (productName != null && !productName.isEmpty()) {
            sql.append(" AND Name LIKE ?");
            parameters.add("%" + productName + "%");
        }
        if (productCategory != null && !productCategory.isEmpty()) {
            sql.append(" AND Category = ?");
            parameters.add(productCategory);
        }
        if (productSeller != null && !productSeller.isEmpty()) {
            sql.append(" AND SellerUsername = ?");
            parameters.add(productSeller);
        }
        if (productPrice != null && productPrice > 0) {
            sql.append(" AND Price <= ?");
            parameters.add(productPrice);
        }
        if (productSize != null && productSize > 0) {
            sql.append(" AND ProductSize = ?");
            parameters.add(productSize);
        }
        if (productSizeUnit != null && !productSizeUnit.isEmpty()) {
            sql.append(" AND ProductUnit = ?");
            parameters.add(productSizeUnit);
        }
        if (available != null) {
            sql.append(" AND Available = ?");
            parameters.add(available);
        }
        if (productDescription != null && !productDescription.isEmpty()) {
            sql.append(" AND Description LIKE ?");
            parameters.add("%" + productDescription + "%"); // Partial match search
        }
        if (productStock != null && productStock > 0) {
            sql.append(" AND Stock >= ?");
            parameters.add(productStock);
        }

        ProductXML productXML = new ProductXML();
        ArrayList<Product> productList = new ArrayList<>();

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) { 

            for (int i = 0; i < parameters.size(); i++) {
                ps.setObject(i + 1, parameters.get(i));
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product product = new Product();
                product.setProductName(rs.getString("Name"));
                product.setProductSeller(rs.getString("SellerUsername"));
                product.setProductDescription(rs.getString("Description"));
                product.setProductPrice(rs.getDouble("Price"));
                product.setProductStock(rs.getInt("Stock"));
                product.setProductSize(rs.getDouble("ProductSize"));
                product.setProductSizeUnit(rs.getString("ProductUnit"));
                product.setProductCategory(rs.getString("Category"));
                product.setAvailable(rs.getBoolean("Available"));

                productList.add(product);
            }

            productXML.setProducts(productList);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return productXML; 
    }*/
    
    public static boolean addProduct(String productName, String productCategory, String productSeller, double productPrice, double productSize, String productSizeUnit, boolean available, String productDescription, int productStock) {
       String sql = "INSERT INTO Product (Name, Category, SellerUsername, Price, ProductSize, ProductUnit, " +
                    "Available, Description, Stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

       try (Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) { 

           ps.setString(1, productName);
           ps.setString(2, productCategory);
           ps.setString(3, productSeller);
           ps.setDouble(4, productPrice);
           ps.setDouble(5, productSize);
           ps.setString(6, productSizeUnit);
           ps.setBoolean(7, available);
           ps.setString(8, productDescription);
           ps.setInt(9, productStock);

           int rowsInserted = ps.executeUpdate();
           return rowsInserted > 0;

       } catch (Exception e) {
           e.printStackTrace();
           return false;
       }
    }
    
    public static boolean deleteProduct(String productName, String productSeller) {
        String sql = "DELETE FROM Product WHERE Name = ? AND SellerUsername = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) { 

            ps.setString(1, productName);
            ps.setString(2, productSeller);

            int rowsDeleted = ps.executeUpdate();
            return rowsDeleted > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String category = request.getParameter("category");
        String priceRange = request.getParameter("price");

        // Database connection details
        String url = "jdbc:mysql://localhost:3306/Farm2Cart";
        String username = "student";
        String password = "student";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        List<String> productNames = new ArrayList<>();
        List<String> productCategories = new ArrayList<>();
        List<String> productPrices = new ArrayList<>();
        List<String> productDescriptions = new ArrayList<>();

        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement();

            
            StringBuilder query = new StringBuilder("SELECT * FROM Product");

            
            if (category != null && !category.equals("all")) {
                query.append(" WHERE Category = '").append(category).append("'");
            }

            
            if (priceRange != null) {
                if (category != null && !category.equals("all")) {
                    query.append(" AND ");
                } else {
                    query.append(" WHERE ");
                }

                if (priceRange.equals("low")) {
                    query.append("Price < 2");
                } else if (priceRange.equals("medium")) {
                    query.append("Price BETWEEN 3 AND 5");
                } else if (priceRange.equals("high")) {
                    query.append("Price > 5");
                }
            }

            
            rs = stmt.executeQuery(query.toString());

            while (rs.next()) {
                productNames.add(rs.getString("Name"));
                productCategories.add(rs.getString("Category"));
                productPrices.add("$" + rs.getString("Price"));
                productDescriptions.add(rs.getString("Description"));
            }

            
            request.setAttribute("productNames", productNames);
            request.setAttribute("productCategories", productCategories);
            request.setAttribute("productPrices", productPrices);
            request.setAttribute("productDescriptions", productDescriptions);

            
            RequestDispatcher dispatcher = request.getRequestDispatcher("browse.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database Error");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}