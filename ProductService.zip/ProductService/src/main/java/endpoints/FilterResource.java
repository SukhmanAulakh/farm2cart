package endpoints;

import business.FilterBusiness;
import helper.ProductXML;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service for filtering products.
 */
@Path("filter")
public class FilterResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of FilterResource.
     */
    public FilterResource() {
    }
    
    /**
     * Retrieves a filtered list of products based on query parameters.
     * @param query
     * @return XML representation of products.
     */
    @GET
    @Path("search")
    @Produces(MediaType.APPLICATION_XML + ";charset=utf-8")
    public String getXml(@QueryParam("query") String query){
        FilterBusiness filter= new FilterBusiness();
        ProductXML products = filter.getProductsByQuery(query);
        System.out.println(">>>>>>>>>>>>>>>>>>" + products);
        
        JAXBContext jaxbContext;
        try {
            jaxbContext = JAXBContext.newInstance(ProductXML.class);
        
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(products, sw);

            return (sw.toString());

          } catch (JAXBException ex) {
                Logger.getLogger(FilterResource.class.getName()).log(Level.SEVERE, null, ex);
                return("error happened");
        }
    }


    /**
     * Updates or creates an instance of FilterResource.
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
        // TODO: Implement PUT method logic
    }
}
