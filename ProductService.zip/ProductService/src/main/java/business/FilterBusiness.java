/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import helper.ProductXML;
import static java.lang.System.in;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import helper.Product;
import persistence.Product_CRUD;

/**
 *
 * @author student
 */
public class FilterBusiness {
    
    public  ProductXML getProductsByQuery(String query){
       Set<Product> products = Product_CRUD.searchForProducts(query);
       Map<String ,Product> allProducts= new HashMap ();
           System.out.println("&&&&&&&&&&&&&&&&&&&&&&"+ products.size());
        for(Product product : products){
            if(allProducts.containsKey(product.getProductName())){
                allProducts.get(product.getProductName());
            }
            else{
               
                allProducts.put(product.getProductName(),product );
            }
        }
        System.out.println("**********************"+ allProducts.size());
        ProductXML ps;
        ps = new ProductXML();
        ps.setProducts(new ArrayList(allProducts.values()));
        return ps;
    }
    
      
}
