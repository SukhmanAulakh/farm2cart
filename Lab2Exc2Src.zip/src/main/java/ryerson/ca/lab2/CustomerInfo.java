/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ryerson.ca.lab2;

import java.util.ArrayList;

/**
 *
 * @author student
 */
public class CustomerInfo {
    private ArrayList <Product> cart = new ArrayList<>();
    public void addToCart(Product item){
        cart.add(item);
    }
    public ArrayList<Product> getCart(){
        return cart;
    }
}
