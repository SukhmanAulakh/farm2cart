/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.USER_CRUD;
import java.util.ArrayList;

/**
 *
 * @author student
 */
public class CustomerInfo {
    private String username;
    private String password;
    private boolean loginStatus;
    private ArrayList <Product> cart = new ArrayList<>();
    
    public CustomerInfo(String username,String password) {
        this.username = username;
        this.password = password;
        
        loginStatus=checkCustomerLogin();
    }
    
    private boolean checkCustomerLogin(){
        return USER_CRUD.checkCustomerLogin(username, password);
    }
    
    public boolean getLoginStatus()
    {
        return loginStatus;
    }
    
    public String getUsername()
    {
        return username;
    }

    public void addToCart(Product item){
        cart.add(item);
    }
    public ArrayList<Product> getCart(){
        return cart;
    }
}
