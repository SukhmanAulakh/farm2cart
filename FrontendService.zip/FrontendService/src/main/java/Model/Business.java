package Model;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;


/**
 * Business logic for interacting with the Product Service API.
 */
public class Business {

    /**
     * Checks if a user is authenticated (placeholder implementation).
     */
    public static boolean isAuthenticated(String username, String password) {
        return true; // TODO: Replace with real authentication logic
    }

    /**
     * Calls the Product Service API to retrieve filtered products.
     *
     * @param query     Product name filter
     * @return A {@code ProductXML} object containing filtered products
     * @throws IOException If an error occurs during API communication
     */

    public static ProductXML getServices(String query) throws IOException {
    System.out.println("[INFO] Connecting to API with query: " + query);

    // URL Encode the query parameter
    String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);
    
    // Use absolute URL with 127.0.0.1 instead of localhost
    String apiUrl = "http://127.0.0.1:8080/ProductService/webresources/filter/search";
    
    Client client = ClientBuilder.newClient(new ClientConfig().property(ClientProperties.FOLLOW_REDIRECTS, true));
    WebTarget searchWebTarget = client.target(apiUrl).queryParam("query", encodedQuery);

    System.out.println("[DEBUG] Requesting API at: " + searchWebTarget.getUri());

    // Make GET request with additional headers
    Response response = searchWebTarget.request()
                                       .header("User-Agent", "Mozilla/5.0") // Prevent API from blocking Java client
                                       .accept(MediaType.APPLICATION_XML)
                                       .get();

    // Debugging Response Code
    System.out.println("[DEBUG] Response Code: " + response.getStatus());
    if (response.getStatus() == 404) {
        System.err.println("[ERROR] API returned 404. Check endpoint or required headers.");
        throw new IOException("API endpoint not found: " + searchWebTarget.getUri());
    }

    // Try-with-resources for InputStream
    try (InputStream is = response.readEntity(InputStream.class)) {
        String xml = IOUtils.toString(is, StandardCharsets.UTF_8);
        System.out.println("[INFO] XML Response received for query: " + query);
        
        // Parse XML
        ProductXML products = productxmltoObjects(xml);
        System.out.println("[INFO] Successfully parsed ProductXML for query: " + query);
        return products;
    } catch (Exception e) {
        System.err.println("[ERROR] Failed to fetch or parse XML: " + e.getMessage());
        throw new IOException("Error retrieving or parsing XML from API", e);
    }
}



    /**
     * Converts XML string into a {@code ProductXML} object.
     *
     * @param xml The XML data as a string
     * @return A {@code ProductXML} object or {@code null} if parsing fails
     */
    private static ProductXML productxmltoObjects(String xml) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(ProductXML.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            return (ProductXML) jaxbUnmarshaller.unmarshal(new StringReader(xml));
        } catch (JAXBException e) {
            System.err.println("[ERROR] XML Parsing Exception: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
