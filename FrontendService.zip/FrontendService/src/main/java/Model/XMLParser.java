/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


public class XMLParser {

    private static short TEXT=3;

    public static String convertProductXMLToHTML(ProductXML productXML) {
        StringBuilder html = new StringBuilder();

        html.append("<div class='products'>\n"); // Start main container

        for (Product product : productXML.getProducts()) {
            html.append("  <div class='product'>\n");
            html.append("    <h2>").append(product.getProductName()).append("</h2>\n");
            html.append("    <p><strong>Category:</strong> ").append(product.getProductCategory()).append("</p>\n");
            html.append("    <p><strong>Seller:</strong> ").append(product.getProductSeller()).append("</p>\n");
            html.append("    <p><strong>Price:</strong> $").append(product.getProductPrice()).append("</p>\n");
            html.append("    <p><strong>Size:</strong> ").append(product.getProductSize()).append(" ").append(product.getProductSizeUnit()).append("</p>\n");
            html.append("    <p><strong>Stock:</strong> ").append(product.getProductStock()).append("</p>\n");
            html.append("    <p><strong>Available:</strong> ").append(product.isAvailable() ? "Yes" : "No").append("</p>\n");
            html.append("    <p><strong>Description:</strong> ").append(product.getProductDescription()).append("</p>\n");
            html.append("  </div>\n"); // End product div
        }

        html.append("</div>"); // End products container

        return html.toString();
    }

    private static String getChildText(Node node) {
        StringBuilder html=new StringBuilder("");
       /*if(!node.hasChildNodes()){
           html.append("<table> <tr><th>"+node.getNodeName()+"</th></tr><tr><td>"+node.getNodeValue()+"</td></tr>");
           return (html.toString());
       }*/
       
      if (node.getNodeType()==TEXT){
           
               html.append("<td>"+node.getNodeValue()+"</td>");
           return (html.toString());
        
    }
       else{
            html.append("<td><table width=\"100%\" border=\"0\"  cellpadding=\"10\"  cellspacing=\"1\"><tr><th>"+node.getNodeName()+"</th></tr>");
            NodeList nodes = node.getChildNodes();
           
           for(int i=0;i<nodes.getLength(); i++){
               
               html.append(getChildText(nodes.item(i)));
             
           }
           html.append("</table></td>");
           return(html.toString());
       }
    }

}
