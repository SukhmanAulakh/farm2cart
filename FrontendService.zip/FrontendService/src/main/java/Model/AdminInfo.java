/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.USER_CRUD;
import java.util.ArrayList;

/**
 *
 * @author student
 */
public class AdminInfo {
    private String username;
    private String password;
    private boolean loginStatus;
    
    public AdminInfo(String username,String password) {
        this.username = username;
        this.password = password;
        
        loginStatus=checkAdminLogin();
    }
    
    private boolean checkAdminLogin(){
        return USER_CRUD.checkAdminLogin(username, password);
    }
    
    public boolean getLoginStatus()
    {
        return loginStatus;
    }
}
