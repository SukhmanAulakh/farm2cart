package Model;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class USER_CRUD {

    private static Connection getConnection(){
        Connection con=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Farm2Cart?zeroDateTimeBehavior=CONVERT_TO_NULL","root","student");
        }catch(Exception e){System.out.println(e);}
        return con;
    }
    
    // Check Customer login credentials
    public static boolean checkCustomerLogin(String username, String password) {
        boolean valid = false;
        String sql = "SELECT * FROM Farm2Cart.Customer WHERE Username = ? AND Password = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                valid = true;
            } else {
                System.out.println("Customer login failed: Invalid username or password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return valid;
    }
    
    // Check Seller login credentials
    public static boolean checkSellerLogin(String username, String password) {
        boolean valid = false;
        String sql = "SELECT * FROM Farm2Cart.Seller WHERE Username = ? AND Password = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                valid = true;
            } else {
                System.out.println("Customer login failed: Invalid username or password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return valid;
    }
    
    // Check Admin login credentials
    public static boolean checkAdminLogin(String username, String password) {
        boolean valid = false;
        String sql = "SELECT * FROM Farm2Cart.Admin WHERE Username = ? AND Password = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                valid = true;
            } else {
                System.out.println("Admin login failed: Invalid username or password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return valid;
    }
    
    // Register a new customer account (insert new customer into the database)
    public static boolean registerCustomer(String firstName, String lastName, String username, String password, String phoneNo, String address) {
        boolean success = false;
        String sql = "INSERT INTO Customer (FirstName, LastName, Username, Password, PhoneNo, Address) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, username);
            ps.setString(4, password);
            ps.setString(5, phoneNo);
            ps.setString(6, address);
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Customer registration successful.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }
    
    // Register a new customer account (insert new customer into the database)
    public static boolean registerSeller(String firstName, String lastName, String username, String password, String phoneNo, String address) {
        boolean success = false;
        String sql = "INSERT INTO Seller (FirstName, LastName, Username, Password, PhoneNo, Address) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, username);
            ps.setString(4, password);
            ps.setString(5, phoneNo);
            ps.setString(6, address);
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
                System.out.println("Seller registration successful.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }
}