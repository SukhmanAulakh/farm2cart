/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author student
 */
public class Product{
    
    private  boolean available;
    private String productName;
    private String productCategory;
    private String productSeller;
    private double productPrice;
    private double productSize;
    private String productSizeUnit;
    private String productDescription;
    private int productStock;

    /*
    To be completed
     */
    public Product(String productName, String productCategory, String productSeller, double productPrice, double productSize, String productSizeUnit, boolean available, String productDescription, int productStock) {
        this.productName = productName;
        this.productCategory=productCategory;
        this.available=available;
        this.productSeller=productSeller;
        this.productPrice=productPrice;
        this.productSize=productSize;
        this.productSizeUnit=productSizeUnit;
        this.productDescription = productDescription;
        this.productStock=productStock;
    }
    
    public Product() {
        this.productName = null;
        this.productCategory=null;
        this.available=false;
        this.productSeller=null;
        this.productPrice=0;
        this.productSize=0;
        this.productSizeUnit=null;
        this.productDescription = null;
    }
    
    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public String getProductSeller() {
        return productSeller;
    }

    public void setProductSeller(String productSeller) {
        this.productSeller = productSeller;
    }
    
    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
    
    public Double getProductSize() {
        return productSize;
    }

    public void setProductSize(double productSize) {
        this.productSize= productSize;
    }

    public String getProductSizeUnit() {
        return productSizeUnit;
    }

    public void setProductSizeUnit(String productSizeUnit) {
        this.productSizeUnit = productSizeUnit;
    }
    
    public String getProductDescription()
    {
        return productDescription;
    }
    
    public void setProductDescription(String productDescription)
    {
        this.productDescription=productDescription;
    }
    
    public int getProductStock()
    {
        return productStock;
    }
    
    public void setProductStock(int productStock)
    {
        this.productStock=productStock;
    }
}
