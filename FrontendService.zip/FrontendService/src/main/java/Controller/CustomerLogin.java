package Controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Model.CustomerInfo;
import Model.Product;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author student
 */
@WebServlet(name= "CustomerLogin",urlPatterns = {"/CustomerLogin"})
public class CustomerLogin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username=(String) request.getParameter("username");
        String password=(String) request.getParameter("password");
        
        CustomerInfo cinfo=getCustomerInfo(username, password);
        
        if (cinfo==null){
            RequestDispatcher rd= request.getRequestDispatcher("LoginFailed.jsp");
            rd.forward(request, response);
        }
        else{
            request.getSession().setAttribute("uname", cinfo.getUsername());
            request.setAttribute("cartInfo", cinfo.getCart());
            
            RequestDispatcher rd= request.getRequestDispatcher("browseProducts.jsp");
            rd.forward(request, response);
            
        }
    }
     
    private CustomerInfo getCustomerInfo(String uname, String password) {
        CustomerInfo cf= new CustomerInfo(uname,password);
        
        /*if(uname.equals("user")&&password.equals("pass"))
        {
            return cf;
        }
        else
        {
            return null;
        }*/
        if(cf.getLoginStatus()==true)
        {
            return cf;
        }
        else
        {
            return null;
        }
    }
        
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

          doPost(request, response);

        
    }

}
